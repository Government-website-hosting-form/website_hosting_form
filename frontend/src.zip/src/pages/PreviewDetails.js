import { useState, useEffect } from "react"
import Layout from "../components/Layout";
import "./PreviewDetails.css";
import { useNavigate } from "react-router-dom";
import { useFormContext } from "../context/FormContext";
import { apiGet } from "../api";

function PreviewDetails() {
    

    // useState , so that fetched data lives somewhere so that it can be displayed later 
    //useEffect , cause fetching is an api call and we want to do it when the component mounts, not on every render
    const navigate = useNavigate();
    const { ids } = useFormContext();

    const [org, setOrg] = useState(null);
    const [app, setApp] = useState(null);
    const [infra, setInfra] = useState(null);
    const [error, setError] = useState("");

    useEffect(() => {
        async function loadAll() {
            try {
                const [orgData, appData, infraData] = await Promise.all([
                    ids.orgId ? apiGet(`/org/${ids.orgId}`) : null,
                    ids.appId ? apiGet(`/apps/${ids.appId}`) : null,
                    ids.infraId ? apiGet(`/infra/${ids.infraId}`) : null,
                ]);
                setOrg(orgData);
                setApp(appData);
                setInfra(infraData);
            } catch (err) {
                console.error("Could not load preview data:", err);
                setError("Could not load your submission details. Please go back and check each step.");
            }
        }
        loadAll();
    }, [ids.orgId, ids.appId, ids.infraId]);

    function Backpage() {
        navigate("/checklist");
    }

    function handleSubmit() {
        console.log("Submit clicked");
    }

    return (
        <Layout>
            <div className="box">
                <h3>This is a preview of your submission. It has not been submitted yet!</h3>
                <label className="grey">Please take a moment to verify your information. You can also go back to make changes.</label>
            </div>

            {org && (
    <div className="form-section">
        <div className="section-header">
            <span className="section-badge">1</span>
            <h3>Organization Details</h3>
        </div>
        <div className="form-section-grid">
            <div className="form-row">
                <label>Organization Name</label>
                <p>{org.name || "-"}</p>
            </div>
            <div className="form-row">
                <label>Organization Type</label>
                <p>{org.type || "-"}</p>
            </div>

             <div className="form-row">
                <label>Organization Other</label>
                <p>{org.type_other || "-"}</p>
            </div>

            <div className="form-row">
                <label> Nodal Officer Name</label>
                <p>{org.officer || "-"}</p>
            </div>

             <div className="form-row">
                <label> Designation</label>
                <p>{org.officer_designation || "-"}</p>
            </div>
             <div className="form-row">
                <label>Email</label>
                <p>{org.email || "-"}</p>
            </div>
             <div className="form-row">
                <label>Office Phone No.</label>
                <p>{org.phone_office || "-"}</p>
            </div>
             <div className="form-row">
                <label>Contact No.</label>
                <p>{org.phone || "-"}</p>
            </div>
             <div className="form-row">
                <label>Office Address</label>
                <p>{org.address || "-"}</p>
            </div>
             <div className="form-row">
                <label>DoIT Officer Name</label>
                <p>{org.contact_name || "-"}</p>
            </div>
             <div className="form-row">
                <label>Designation</label>
                <p>{org.contact_designation || "-"}</p>
            </div>
             <div className="form-row">
                <label>Contact Number</label>
                <p>{org.contact_phone || "-"}</p>
            </div>
             <div className="form-row">
                <label>Email Address</label>
                <p>{org.contact_email || "-"}</p>
            </div>


           
        </div>

        
    </div>


    
)}

    {app && (
    <div className="form-section">
        <div className="section-header">
            <span className="section-badge">2</span>
            <h3>Application Details</h3>
        </div>
        <div className="form-section-grid">
            <div className="form-row">
                <label>Application Name</label>
                <p>{app.name || "-"}</p>
            </div>
            <div className="form-row">
                <label>Type</label>
                <p>{app.type || "-"}</p>
            </div>

             <div className="form-row">
                <label>Type Other </label>
                <p>{app.type_other || "-"}</p>
            </div>

            <div className="form-row">
                <label>Nature</label>
                <p>{app.nature || "-"}</p>
            </div>

             <div className="form-row">
                <label> Utility</label>
                <p>{app.utility || "-"}</p>
            </div>
             <div className="form-row">
                <label>Utility Other</label>
                <p>{app.utility_other || "-"}</p>
            </div>
             <div className="form-row">
                <label>Purpose</label>
                <p>{app.purpose || "-"}</p>
            </div>
             <div className="form-row">
                <label>URL</label>
                <p>{app.url || "-"}</p>
            </div>
             <div className="form-row">
                <label>Alternate URL</label>
                <p>{app.alternate_url || "-"}</p>
            </div>
             <div className="form-row">
                <label>Authority Name</label>
                <p>{app.approval_authority || "-"}</p>
            </div>
             <div className="form-row">
                <label> Designation</label>
                <p>{app.approval_designation || "-"}</p>
            </div>
             <div className="form-row">
                <label>SEMT/Administrative Approval</label>
                <p>{app.semt_approved || "-"}</p>
            </div>
             <div className="form-row">
                <label> MoM / Document Reference No. </label>
                <p>{app.mom_ref_no || "-"}</p>
            </div>
             <div className="form-row">
                <label>Date</label>
                <p>{app.mom_date || "-"}</p>
            </div>
           
        </div>

        
    </div>


    
)}


    {app && (
    <div className="form-section">
        <div className="section-header">
            <span className="section-badge">3</span>
            <h3>Developer, Maintenance Team Details</h3>
        </div>
        <div className="form-section-grid">
            <div className="form-row">
                <label>Name of the Company / Agency</label>
                <p>{app.dev_company || "-"}</p>
            </div>
            <div className="form-row">
                <label>Other Company Name</label>
                <p>{app.dev_company_other || "-"}</p>
            </div>

             <div className="form-row">
                <label>Name of Contact Person </label>
                <p>{app.dev_contact_person || "-"}</p>
            </div>

            <div className="form-row">
                <label>Address</label>
                <p>{app.dev_address || "-"}</p>
            </div>

             <div className="form-row">
                <label> Phone No. (Office)</label>
                <p>{app.dev_phone_office || "-"}</p>
            </div>
             <div className="form-row">
                <label>Phone No. (Mobile)</label>
                <p>{app.dev_phone || "-"}</p>
            </div>
             <div className="form-row">
                <label>E-Mail Address</label>
                <p>{app.dev_email || "-"}</p>
            </div>

             <div className="form-row">
                <label>Website/Application is Under Maintenance</label>
                <p>{app.maint_active || "-"}</p>
            </div>
             <div className="form-row">
                <label>Expiry</label>
                <p>{app.maint_expiry || "-"}</p>
            </div>
             <div className="form-row">
                <label>Name of the Company / Agency maintaining</label>
                <p>{app.maint_company || "-"}</p>
            </div>
             <div className="form-row">
                <label>Name of Contact Person</label>
                <p>{app.maint_contact_person || "-"}</p>
            </div>
             <div className="form-row">
                <label>Address</label>
                <p>{app.maint_address || "-"}</p>
            </div>
             <div className="form-row">
                <label>Phone No.(Office)</label>
                <p>{app.maint_phone_office || "-"}</p>
            </div>
             <div className="form-row">
                <label>Phone No. (Mobile)</label>
                <p>{app.maint_phone_mobile || "-"}</p>
            </div>
            <div className="form-row">
                <label>Email Address</label>
                <p>{app.maint_email || "-"}</p>
            </div>
            <div className="form-row">
                <label>Contract Copy(ies) Attached</label>
                <p>{app.maint_contract_attached || "-"}</p>
            </div>
           
        </div>

        
    </div>


    
)}

    {app && (
    <div className="form-section">
        <div className="section-header">
            <span className="section-badge">4</span>
            <h3>Certificate Details</h3>
        </div>
        <div className="form-section-grid">
            <div className="form-row">
                <label>Name of Certifying Agency</label>
                <p>{app.safehost_agency || "-"}</p>
            </div>
            <div className="form-row">
                <label>Other Certifying Agency</label>
                <p>{app.safehost_agency_other || "-"}</p>
            </div>
            <div className="form-row">
                <label>CERT-In Empanelment Number</label>
                <p>{app.safehost_empanel_no || "-"}</p>
            </div>

             <div className="form-row">
                <label>Empanelment Valid Till </label>
                <p>{app.safehost_empanel_valid_till || "-"}</p>
            </div>

            <div className="form-row">
                <label>Security Audit Certificate Reference Number</label>
                <p>{app.safehost_ref_no || "-"}</p>
            </div>

             <div className="form-row">
                <label> Certificate Issue Date</label>
                <p>{app.safehost_issue_date || "-"}</p>
            </div>
             <div className="form-row">
                <label>Certificate Valid Till</label>
                <p>{app.safehost_valid_till || "-"}</p>
            </div>
             <div className="form-row">
                <label>Name of Certifying Agency for Load Test Certificate Details</label>
                <p>{app.loadtest_agency || "-"}</p>
            </div>

            <div className="form-row">
                <label>Other Certifying Agency</label>
                <p>{app.loadtest_agency_other || "-"}</p>
            </div>

             <div className="form-row">
                <label>Load Tested (Maximum Users)</label>
                <p>{app.load_users || "-"}</p>
            </div>
             <div className="form-row">
                <label>Average Response Time</label>
                <p>{app.loadtest_avg_response || "-"}</p>
            </div>
             <div className="form-row">
                <label>Certificate Reference Number</label>
                <p>{app.loadtest_ref_no || "-"}</p>
            </div>
             <div className="form-row">
                <label>Certificate Issue Date</label>
                <p>{app.loadtest_issue_date || "-"}</p>
            </div> 
             <div className="form-row">
                <label>Certificate Valid Till</label>
                <p>{app.loadtest_valid_till || "-"}</p>
            </div>
             <div className="form-row">
                <label>Other Certificate Details</label>
                <p>{app.other_certificate_details || "-"}</p>
            </div>
           
        </div>

        
    </div>


    
)}


            {error && <p className="form-error">{error}</p>}

          

            <input type="button" value="Previous" onClick={Backpage} className="back-button" />
            <input type="button" value="Submit" onClick={handleSubmit} className="submit-button" />
        </Layout>
    );
}

export default PreviewDetails;